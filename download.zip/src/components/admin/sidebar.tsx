'use client';

import * as React from "react";
import {
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarGroup,
  SidebarGroupLabel,
  SidebarGroupContent,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { 
  LayoutDashboard, 
  Settings, 
  FileEdit, 
  BookOpen, 
  Users, 
  MessageSquare, 
  Bell, 
  Globe, 
  Palette,
  BarChart,
  LogOut,
  ChevronRight,
  ShieldCheck,
  Smartphone,
} from "lucide-react";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import NextLink from 'next/link';

const MENU_ITEMS = [
  { group: "Analytics", items: [
    { label: "System Overview", icon: LayoutDashboard, href: "/support" },
    { label: "Performance", icon: BarChart, href: "/support/analytics" },
    { label: "Realtime Load", icon: Smartphone, href: "/support/realtime" },
  ]},
  { group: "Orchestration Studio", items: [
    { label: "Pages CMS", icon: Globe, href: "/support/pages" },
    { label: "Curriculum Catalog", icon: BookOpen, href: "/support/courses" },
    { label: "Insight Journal", icon: FileEdit, href: "/support/blogs" },
    { label: "Platform Updates", icon: Bell, href: "/support/updates" },
  ]},
  { group: "Identity & Ops", items: [
    { label: "User Access", icon: Users, href: "/support/users" },
    { label: "Assessments", icon: ShieldCheck, href: "/support/tests" },
    { label: "Hub Interactions", icon: MessageSquare, href: "/support/community" },
  ]},
  { group: "Core Engine", items: [
    { label: "Brand Design", icon: Palette, href: "/support/theme" },
    { label: "System Settings", icon: Settings, href: "/support/settings" },
  ]}
];

export function AdminSidebar() {
  const pathname = usePathname();

  return (
    <Sidebar variant="inset" collapsible="icon" className="border-r-0">
      <SidebarHeader className="border-b h-16 flex items-center px-4 bg-background">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-primary flex items-center justify-center shadow-xl shadow-primary/20 border-2 border-accent/20">
            <span className="text-white font-bold text-xs tracking-tighter">XC</span>
          </div>
          <div className="flex flex-col group-data-[collapsible=icon]:hidden">
            <span className="font-headline font-bold text-base leading-tight">XmartyCreator Support</span>
            <span className="text-[10px] text-primary uppercase tracking-[0.2em] font-bold">Admin Console v2.0</span>
          </div>
        </div>
      </SidebarHeader>
      <SidebarContent className="px-2 py-6 bg-background">
        {MENU_ITEMS.map((group) => (
          <SidebarGroup key={group.group} className="mb-4">
            <SidebarGroupLabel className="px-4 text-[10px] font-bold uppercase tracking-[0.3em] text-muted-foreground/50 group-data-[collapsible=icon]:hidden">
              {group.group}
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {group.items.map((item) => {
                  const isActive = pathname === item.href;
                  return (
                    <SidebarMenuItem key={item.label}>
                      <SidebarMenuButton 
                        asChild 
                        isActive={isActive}
                        className={cn(
                          "transition-all duration-300 rounded-xl h-11 px-4",
                          isActive ? "bg-primary text-primary-foreground shadow-xl shadow-primary/20" : "hover:bg-primary/5 text-muted-foreground hover:text-primary"
                        )}
                      >
                        <NextLink href={item.href}>
                          <item.icon className={cn("w-4 h-4", isActive ? "text-primary-foreground" : "")} />
                          <span className="group-data-[collapsible=icon]:hidden font-bold">{item.label}</span>
                          {isActive && <ChevronRight className="ml-auto w-3 h-3 group-data-[collapsible=icon]:hidden" />}
                        </NextLink>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  );
                })}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        ))}
      </SidebarContent>
      <SidebarFooter className="p-4 border-t bg-background">
        <SidebarMenuButton className="text-destructive hover:bg-destructive/10 hover:text-destructive group-data-[collapsible=icon]:justify-center h-12 rounded-xl font-bold" asChild>
           <NextLink href="/">
            <LogOut className="w-4 h-4" />
            <span className="group-data-[collapsible=icon]:hidden">Exit Orchestration</span>
           </NextLink>
        </SidebarMenuButton>
      </SidebarFooter>
    </Sidebar>
  );
}