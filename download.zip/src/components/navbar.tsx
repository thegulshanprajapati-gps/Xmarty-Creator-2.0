'use client';

import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Settings, Menu, X, User, Sun, Moon, Bell, Search } from "lucide-react";
import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";
import { useCMS } from "@/components/cms-provider";
import { useUser } from "@/firebase";
import { doc, getFirestore, updateDoc } from "firebase/firestore";
import { usePathname } from "next/navigation";
import { motion } from "framer-motion";

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { settings } = useCMS();
  const { user } = useUser();
  const db = getFirestore();
  const pathname = usePathname();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const toggleTheme = () => {
    const newMode = settings?.themeMode === 'dark' ? 'light' : 'dark';
    const ref = doc(db, 'config', 'settings');
    updateDoc(ref, { themeMode: newMode });
  };

  const links = [
    { label: "Home", href: "/" },
    { label: "About", href: "/about" },
    { label: "Courses", href: "/courses" },
    { label: "Community", href: "/community" },
    { label: "Blog", href: "/blog" },
    { label: "Contact", href: "/contact" },
  ];

  return (
    <nav className={cn(
      "fixed top-0 z-[100] w-full transition-all duration-300 overflow-y-hidden overflow-x-hidden",
      scrolled ? "bg-background/95 backdrop-blur-md border-b py-2 shadow-sm" : "bg-background py-3"
    )}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-14 items-center">
          <div className="flex items-center">
            <Link href="/" className="flex items-center gap-3 group">
              <div className="bg-primary h-9 w-9 rounded-full flex items-center justify-center shadow-lg shadow-primary/30 border-2 border-accent/20">
                <span className="text-white font-bold text-sm tracking-tighter">XC</span>
              </div>
              <span className="font-headline text-xl font-bold tracking-tight text-foreground/90 group-hover:text-primary transition-colors">
                XmartyCreator
              </span>
            </Link>
          </div>

          <div className="hidden lg:flex items-center gap-1 bg-muted/40 p-1 rounded-full border border-primary/5 relative">
            {links.map((link) => {
              const isActive = pathname === link.href;
              return (
                <Link 
                  key={link.href} 
                  href={link.href} 
                  className={cn(
                    "relative px-5 py-2 text-sm font-bold transition-colors duration-300 rounded-full z-10",
                    isActive ? "text-white" : "text-muted-foreground hover:text-foreground"
                  )}
                >
                  {isActive && (
                    <motion.div
                      layoutId="nav-pill"
                      className="absolute inset-0 bg-primary rounded-full -z-10 shadow-lg shadow-primary/30"
                      transition={{ type: "spring", bounce: 0.25, duration: 0.5 }}
                    />
                  )}
                  {link.label}
                </Link>
              );
            })}
          </div>

          <div className="hidden lg:flex items-center gap-2">
            <Button variant="ghost" size="icon" asChild className="rounded-full h-10 w-10 text-muted-foreground hover:text-primary transition-colors">
              <Link href="/updates">
                <Bell className="h-5 w-5" />
              </Link>
            </Button>
            
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={toggleTheme}
              className="rounded-full h-10 w-10 text-muted-foreground hover:text-primary transition-colors"
            >
              {settings?.themeMode === 'dark' ? (
                <Sun className="h-5 w-5 text-amber-500" />
              ) : (
                <Moon className="h-5 w-5 text-primary" />
              )}
            </Button>

            <Button variant="ghost" size="icon" className="rounded-full h-10 w-10 text-muted-foreground hover:text-primary transition-colors">
              <Search className="h-5 w-5" />
            </Button>
            
            <div className="h-6 w-px bg-border mx-2" />

            <Button variant="ghost" size="icon" className="rounded-full h-10 w-10 text-muted-foreground hover:text-primary transition-all hover:scale-110" asChild>
              <Link href="/login">
                <User className="h-5 w-5" />
              </Link>
            </Button>
            
            {(user?.role === 'admin' || user?.role === 'super_admin') && (
              <Button variant="outline" size="icon" asChild className="h-10 w-10 rounded-full border-2 border-accent/50 hover:bg-accent/5 transition-all">
                <Link href="/support">
                  <Settings className="h-4 w-4 text-accent" />
                </Link>
              </Button>
            )}
          </div>

          <div className="lg:hidden flex items-center gap-2">
            <Button variant="ghost" size="icon" asChild className="rounded-full h-10 w-10">
              <Link href="/updates">
                <Bell className="h-5 w-5" />
              </Link>
            </Button>
            <button 
              onClick={() => setIsOpen(!isOpen)} 
              className="p-2 rounded-lg hover:bg-muted transition-colors"
            >
              {isOpen ? <X className="h-7 w-7 text-primary" /> : <Menu className="h-7 w-7 text-primary" />}
            </button>
          </div>
        </div>
      </div>

      <div className={cn(
        "lg:hidden absolute top-full left-0 w-full bg-background border-b overflow-y-hidden transition-all duration-300 shadow-2xl z-50", 
        isOpen ? "max-h-screen opacity-100" : "max-h-0 opacity-0"
      )}>
        <div className="px-6 py-10 space-y-4 bg-background">
          {links.map((link) => (
            <Link 
              key={link.href} 
              href={link.href} 
              className={cn(
                "block text-xl font-headline font-bold p-4 rounded-2xl transition-all",
                pathname === link.href ? "bg-primary text-white shadow-xl shadow-primary/20" : "hover:bg-muted"
              )}
              onClick={() => setIsOpen(false)}
            >
              {link.label}
            </Link>
          ))}
          <div className="pt-8 flex flex-col gap-4">
            <Button variant="outline" className="w-full h-14 text-xl font-bold border-2 rounded-2xl flex items-center justify-center gap-2" asChild>
              <Link href="/login">
                <User className="h-6 w-6" />
                Student Access
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
}