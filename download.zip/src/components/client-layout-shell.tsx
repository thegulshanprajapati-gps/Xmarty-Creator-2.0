'use client';

import { usePathname } from 'next/navigation';
import { Navbar } from "@/components/navbar";
import { Footer } from "@/components/footer";
import { VasantAI } from "@/components/vasant-ai";
import { PageTransition } from "@/components/page-transition";
import { Toaster } from "@/components/ui/toaster";
import { useEffect, useState } from 'react';

export function ClientLayoutShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const isSupportRoute = pathname?.startsWith('/support');
  const isAuthRoute = pathname === '/login';
  const isHome = pathname === '/';
  const shouldHideSiteChrome = isSupportRoute || isAuthRoute;

  if (!mounted) {
    return (
      <div className="flex-grow flex flex-col min-h-screen">
        {children}
      </div>
    );
  }

  return (
    <>
      {!shouldHideSiteChrome && <Navbar />}
      <PageTransition>
        <main className="flex-grow w-full max-w-full overflow-x-hidden">
          {children}
        </main>
      </PageTransition>
      {!shouldHideSiteChrome && !isHome && <Footer />}
      {!shouldHideSiteChrome && <VasantAI />}
      <Toaster />
    </>
  );
}