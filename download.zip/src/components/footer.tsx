'use client';

import Link from "next/link";
import { GraduationCap, Facebook, Twitter, Instagram, Youtube, Linkedin, Send, Settings, ArrowUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useCMS } from "@/components/cms-provider";

export function Footer() {
  const { settings } = useCMS();
  
  const currentYear = new Date().getFullYear();
  
  const footerLinks = settings?.footerLinks || {
    platform: [
      { label: "Home", href: "/" },
      { label: "About", href: "/about" },
      { label: "Courses", href: "/courses" },
      { label: "Community", href: "/community" },
      { label: "Blog", href: "/blog" },
    ],
    support: [
      { label: "Updates", href: "/updates" },
      { label: "Contact", href: "/contact" },
      { label: "FAQ", href: "/faq" },
      { label: "Support Portal", href: "/support/login" },
    ],
    legal: [
      { label: "Privacy Policy", href: "/privacy" },
      { label: "Terms of Service", href: "/terms" },
      { label: "Refund Policy", href: "/refund" },
    ]
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-muted/30 border-t pt-24 pb-12 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-16 mb-20">
          {/* Brand Section */}
          <div className="space-y-8">
            <Link href="/" className="flex items-center gap-3 group">
              <div className="bg-primary p-2.5 rounded-xl group-hover:bg-primary/90 transition-all shadow-lg shadow-primary/20">
                <GraduationCap className="h-7 w-7 text-primary-foreground" />
              </div>
              <span className="font-headline text-2xl font-bold tracking-tight text-primary">
                {settings?.siteName || "XmartyCreator"}
              </span>
            </Link>
            <p className="text-muted-foreground text-sm leading-relaxed max-w-xs">
              {settings?.footerContent?.aboutText || "XmartyCreator: The world-class EdTech ecosystem designed for industrial mastery. We merge architectural excellence with personalized AI mentoring."}
            </p>
            <div className="flex gap-4">
              {[Instagram, Twitter, Youtube, Linkedin].map((Icon, i) => (
                <Link key={i} href="#" className="h-10 w-10 rounded-xl bg-background border flex items-center justify-center hover:bg-primary hover:text-white hover:border-primary transition-all shadow-sm">
                  <Icon className="h-5 w-5" />
                </Link>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-headline font-bold text-sm uppercase tracking-[0.2em] text-primary mb-8">Platform</h4>
            <ul className="space-y-4">
              {footerLinks.platform.map((link: any) => (
                <li key={link.href}>
                  <Link href={link.href} className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors flex items-center group">
                    <span className="w-0 h-px bg-primary mr-0 group-hover:w-4 group-hover:mr-2 transition-all" />
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-headline font-bold text-sm uppercase tracking-[0.2em] text-primary mb-8">Support</h4>
            <ul className="space-y-4">
              {footerLinks.support.map((link: any) => (
                <li key={link.href}>
                  <Link href={link.href} className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors flex items-center group">
                    <span className="w-0 h-px bg-primary mr-0 group-hover:w-4 group-hover:mr-2 transition-all" />
                    {link.label}
                    {link.label === "Support Portal" && <Settings className="h-3 w-3 ml-2 opacity-50" />}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Newsletter */}
          <div className="space-y-8">
            <h4 className="font-headline font-bold text-sm uppercase tracking-[0.2em] text-primary mb-8">Stay Updated</h4>
            <p className="text-sm text-muted-foreground leading-relaxed">
              {settings?.footerContent?.newsletterHeading || "Join 45,000+ creators for weekly tech insights, course launches, and industry updates."}
            </p>
            <div className="flex gap-2">
              <Input placeholder="Enter your email" className="bg-background border-2 h-12 focus-visible:ring-primary" />
              <Button size="icon" className="shrink-0 h-12 w-12 bg-primary shadow-lg shadow-primary/20">
                <Send className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>

        <div className="border-t border-primary/10 pt-12 flex flex-col md:flex-row justify-between items-center gap-8">
          <p className="text-sm text-muted-foreground font-medium">
            © {currentYear} <span className="text-primary font-bold">XmartyCreator</span>. All rights reserved. Designed for Excellence.
          </p>
          <div className="flex flex-wrap justify-center gap-8">
            {footerLinks.legal.map((link: any) => (
              <Link key={link.href} href={link.href} className="text-xs font-bold text-muted-foreground hover:text-primary transition-colors uppercase tracking-widest">{link.label}</Link>
            ))}
          </div>
          <Button variant="outline" size="icon" onClick={scrollToTop} className="rounded-full border-2 border-primary/20 hover:bg-primary/5 shadow-sm">
            <ArrowUp className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </footer>
  );
}
