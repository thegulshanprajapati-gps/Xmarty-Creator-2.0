'use client';

import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, SlidersHorizontal, BookOpen, Clock, User, Filter } from "lucide-react";
import Image from "next/image";
import Link from "next/link";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

const COURSES = [
  {
    id: '1',
    title: 'Advanced Indigo Web Architecture',
    instructor: 'Dr. Sarah Indigo',
    duration: '12 Hours',
    level: 'Advanced',
    students: '1.2k',
    price: '$99.00',
    category: 'Architecture',
    image: "https://picsum.photos/seed/indigo1/800/600"
  },
  {
    id: '2',
    title: 'Enterprise Microservices with Node.js',
    instructor: 'Marcus Aurelius',
    duration: '8 Hours',
    level: 'Intermediate',
    students: '800',
    price: '$79.00',
    category: 'Backend',
    image: "https://picsum.photos/seed/arch/800/600"
  },
  {
    id: '3',
    title: 'UI/UX Excellence: Mastering ShadCN',
    instructor: 'Jessica Walters',
    duration: '15 Hours',
    level: 'Beginner',
    students: '2.5k',
    price: '$129.00',
    category: 'Frontend',
    image: "https://picsum.photos/seed/ai-design/800/600"
  }
];

export default function CoursesPage() {
  const categories = ["All", "Programming", "Architecture", "Backend", "Frontend", "Placement Prep"];

  return (
    <div className="min-h-screen bg-background">
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="space-y-12">
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div className="space-y-4 text-center md:text-left">
              <Badge variant="outline" className="text-primary border-primary/20">CURRICULUM</Badge>
              <h1 className="text-5xl lg:text-7xl font-headline font-bold">Course Library</h1>
              <p className="text-xl text-muted-foreground max-w-xl">
                Expert-led courses designed for the enterprise landscape of XmartyCreator.
              </p>
            </div>
            <div className="flex gap-4 w-full md:w-auto">
              <div className="relative flex-1 md:w-80">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input placeholder="Search courses..." className="pl-10 h-12 rounded-xl" />
              </div>
              <Button variant="outline" size="icon" className="h-12 w-12 rounded-xl border-2">
                <SlidersHorizontal className="h-5 w-5" />
              </Button>
            </div>
          </div>

          {/* Categories */}
          <div className="flex gap-3 overflow-x-auto pb-4 scrollbar-hide">
            {categories.map((cat) => (
              <Button 
                key={cat} 
                variant={cat === "All" ? "default" : "outline"} 
                className={cn("rounded-full px-6 font-bold whitespace-nowrap", cat === "All" ? "shadow-lg shadow-primary/20" : "border-2")}
              >
                {cat}
              </Button>
            ))}
          </div>

          {/* Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
            {COURSES.map((course, idx) => (
              <motion.div
                key={course.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
              >
                <Card className="group overflow-hidden hover:shadow-2xl hover:-translate-y-2 transition-all duration-500 border-primary/5 rounded-[2rem]">
                  <div className="relative aspect-video overflow-hidden">
                    <Image
                      src={course.image}
                      alt={course.title}
                      fill
                      className="object-cover group-hover:scale-105 transition-transform duration-700"
                      data-ai-hint="course thumbnail"
                    />
                    <div className="absolute top-4 left-4 flex gap-2">
                      <Badge className="bg-white/90 text-black backdrop-blur-sm border-none font-bold">{course.category}</Badge>
                      <Badge className="bg-accent text-accent-foreground border-none font-bold">{course.level}</Badge>
                    </div>
                  </div>
                  <CardHeader className="pb-2">
                    <div className="flex items-center gap-2 text-xs text-muted-foreground mb-1 font-bold uppercase tracking-wider">
                      <User className="h-3 w-3" />
                      <span>{course.instructor}</span>
                    </div>
                    <CardTitle className="font-headline text-2xl group-hover:text-primary transition-colors leading-tight">
                      {course.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-6 text-sm text-muted-foreground">
                      <div className="flex items-center gap-2 font-medium">
                        <Clock className="h-4 w-4 text-primary" />
                        <span>{course.duration}</span>
                      </div>
                      <div className="flex items-center gap-2 font-medium">
                        <BookOpen className="h-4 w-4 text-primary" />
                        <span>{course.students} Students</span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex items-center justify-between border-t mt-4 pt-6 bg-muted/20">
                    <span className="text-2xl font-bold text-primary">{course.price}</span>
                    <Button asChild size="lg" className="bg-primary hover:bg-primary/90 font-bold rounded-xl shadow-lg shadow-primary/20">
                      <Link href={`/courses/${course.id}`}>Enroll Now</Link>
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
