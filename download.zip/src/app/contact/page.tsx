'use client';

import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Mail, Phone, MapPin, Send, MessageSquare, Clock, Globe } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

export default function ContactPage() {
  return (
    <div className="min-h-screen">
      <main>
        {/* Hero */}
        <section className="py-24 bg-muted/20 border-b">
          <div className="max-w-7xl mx-auto px-4 text-center space-y-6">
            <Badge variant="outline" className="px-6 py-1 text-primary border-primary/20 rounded-full font-bold">GET IN TOUCH</Badge>
            <h1 className="text-6xl lg:text-8xl font-headline font-bold tracking-tight">How can we <span className="text-primary underline decoration-wavy">help?</span></h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              Our administrative orchestration team and Vasant AI are ready to assist with your educational journey at XmartyCreator.
            </p>
          </div>
        </section>

        <section className="py-32">
          <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 lg:grid-cols-3 gap-20">
            {/* Contact Info */}
            <div className="lg:col-span-1 space-y-12">
              <div className="space-y-6">
                <h3 className="text-3xl font-headline font-bold">Platform Support</h3>
                <p className="text-muted-foreground text-lg leading-relaxed">
                  Have a specific question about XmartyCreator modules or career paths? Reach out via any of these channels.
                </p>
              </div>

              <div className="space-y-10">
                <ContactInfoItem 
                  icon={Mail} 
                  title="Administrative Email" 
                  value="hello@xmartycreator.com" 
                  desc="Expect a reply within 2 hours during orchestration cycles." 
                />
                <ContactInfoItem 
                  icon={Phone} 
                  title="Direct Support" 
                  value="+91 98765 43210" 
                  desc="Available Mon-Fri, 9am - 6pm (IST)." 
                />
                <ContactInfoItem 
                  icon={MapPin} 
                  title="Global Orchestration" 
                  value="Tech Hub Tower, Silicon Valley" 
                  desc="Our central management and AI operations center." 
                />
              </div>

              <Card className="bg-primary text-primary-foreground rounded-[2rem] shadow-2xl overflow-hidden border-none group">
                <CardContent className="p-8 flex items-center gap-6">
                  <div className="h-14 w-14 bg-white/20 rounded-2xl flex items-center justify-center transition-transform group-hover:scale-110 duration-500">
                    <Clock className="h-8 w-8 text-white" />
                  </div>
                  <div>
                    <p className="font-bold text-xl leading-tight">24/7 AI System</p>
                    <p className="opacity-70 text-sm font-medium">Vasant AI is currently ACTIVE.</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Form */}
            <div className="lg:col-span-2">
              <Card className="border-primary/5 shadow-2xl rounded-[3rem] overflow-hidden p-8 md:p-16 relative">
                <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 blur-3xl rounded-full -z-10" />
                <form className="space-y-10">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                    <div className="space-y-3">
                      <Label htmlFor="name" className="text-lg font-bold">Full Name</Label>
                      <Input id="name" placeholder="John Doe" className="h-14 rounded-2xl border-2 shadow-sm focus-visible:ring-primary" />
                    </div>
                    <div className="space-y-3">
                      <Label htmlFor="email" className="text-lg font-bold">Email Address</Label>
                      <Input id="email" type="email" placeholder="john@xmartycreator.com" className="h-14 rounded-2xl border-2 shadow-sm focus-visible:ring-primary" />
                    </div>
                  </div>
                  <div className="space-y-3">
                    <Label htmlFor="subject" className="text-lg font-bold">Subject</Label>
                    <Input id="subject" placeholder="Course Enrollment Inquiry" className="h-14 rounded-2xl border-2 shadow-sm focus-visible:ring-primary" />
                  </div>
                  <div className="space-y-3">
                    <Label htmlFor="message" className="text-lg font-bold">Your Message</Label>
                    <Textarea id="message" placeholder="How can XmartyCreator help you accelerate your career?" className="min-h-[250px] rounded-2xl border-2 shadow-sm resize-none focus-visible:ring-primary" />
                  </div>
                  <Button className="w-full h-16 text-xl font-bold group shadow-2xl shadow-primary/30 transition-all rounded-2xl bg-primary hover:bg-primary/90">
                    Initialize Transmission
                    <Send className="ml-3 h-6 w-6 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                  </Button>
                </form>
              </Card>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}

function ContactInfoItem({ icon: Icon, title, value, desc }: any) {
  return (
    <div className="flex gap-8 group">
      <div className="h-16 w-16 bg-primary/5 rounded-2xl flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-all duration-500 shrink-0 shadow-sm border border-primary/5">
        <Icon className="h-8 w-8" />
      </div>
      <div className="space-y-2">
        <h4 className="font-bold text-xl leading-tight">{title}</h4>
        <p className="text-primary font-bold text-lg leading-tight">{value}</p>
        <p className="text-muted-foreground font-medium leading-relaxed">{desc}</p>
      </div>
    </div>
  );
}
