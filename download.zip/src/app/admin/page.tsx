
import { Navbar } from "@/components/navbar";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { LayoutDashboard, FileText, Users, BarChart3, Settings, Plus, Edit2, Trash2, Eye } from "lucide-react";

export default function AdminCMS() {
  return (
    <div className="min-h-screen bg-muted/30">
      <Navbar />
      <main className="max-w-7xl mx-auto px-4 py-12">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
          <div className="space-y-1">
            <h1 className="text-4xl font-headline font-bold flex items-center gap-3">
              CMS Engine
              <Badge variant="secondary" className="bg-primary/10 text-primary border-none">Enterprise</Badge>
            </h1>
            <p className="text-muted-foreground">Management console for support.xmartycreator.com</p>
          </div>
          <Button size="lg" className="bg-primary">
            <Plus className="mr-2 h-5 w-5" /> Add New Course
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          {[
            { label: "Total Students", value: "45,231", icon: Users, color: "text-blue-600" },
            { label: "Revenue (MTD)", value: "$12,450", icon: BarChart3, color: "text-green-600" },
            { label: "Active Courses", value: "84", icon: FileText, color: "text-purple-600" },
            { label: "Completion Rate", value: "72%", icon: LayoutDashboard, color: "text-orange-600" },
          ].map((stat, i) => (
            <Card key={i}>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">{stat.label}</p>
                    <h3 className="text-2xl font-bold mt-1">{stat.value}</h3>
                  </div>
                  <stat.icon className={`h-8 w-8 opacity-20 ${stat.color}`} />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Tabs defaultValue="courses" className="space-y-6">
          <TabsList className="bg-background border">
            <TabsTrigger value="courses">Content Management</TabsTrigger>
            <TabsTrigger value="users">User Tracking</TabsTrigger>
            <TabsTrigger value="analytics">Orchestration Metrics</TabsTrigger>
          </TabsList>
          
          <TabsContent value="courses">
            <Card>
              <CardHeader>
                <CardTitle className="font-headline">Live Curriculum Catalog</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Course Title</TableHead>
                      <TableHead>Author</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Enrollments</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {[
                      { title: "Advanced Web Arch", author: "Dr. Sarah", status: "Published", count: "1,240" },
                      { title: "Microservices v4", author: "Marcus A.", status: "Draft", count: "0" },
                      { title: "UI Design Pro", author: "Jessica W.", status: "Published", count: "2,501" },
                    ].map((row, i) => (
                      <TableRow key={i}>
                        <TableCell className="font-medium">{row.title}</TableCell>
                        <TableCell>{row.author}</TableCell>
                        <TableCell>
                          <Badge variant={row.status === 'Published' ? 'default' : 'outline'} className={row.status === 'Published' ? 'bg-green-100 text-green-800' : ''}>
                            {row.status}
                          </Badge>
                        </TableCell>
                        <TableCell>{row.count}</TableCell>
                        <TableCell className="text-right space-x-2">
                          <Button variant="ghost" size="icon"><Eye className="h-4 w-4" /></Button>
                          <Button variant="ghost" size="icon"><Edit2 className="h-4 w-4" /></Button>
                          <Button variant="ghost" size="icon" className="text-destructive"><Trash2 className="h-4 w-4" /></Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="users">
            <Card>
              <CardContent className="py-20 text-center text-muted-foreground">
                <Users className="h-12 w-12 mx-auto mb-4 opacity-20" />
                <p>User Identity Management synced with JWT Auth layers.</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
