'use client';

import { useState, useEffect } from "react";
import { SidebarProvider, SidebarInset, SidebarTrigger } from "@/components/ui/sidebar";
import { AdminSidebar } from "@/components/admin/sidebar";
import { Card, CardHeader, CardTitle, CardContent, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Save, ArrowLeft, Loader2, Sparkles, Image as ImageIcon, Plus } from "lucide-react";
import { doc, getFirestore, getDoc, setDoc } from "firebase/firestore";
import { useParams, useRouter } from "next/navigation";
import { toast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function PageEditor() {
  const { pageId } = useParams();
  const router = useRouter();
  const db = getFirestore();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [content, setContent] = useState<any>({
    hero: { title: "", subtitle: "", ctaText: "", ctaHref: "", imageUrl: "" },
    sections: []
  });

  useEffect(() => {
    async function fetchPage() {
      const ref = doc(db, 'pages', pageId as string);
      const snap = await getDoc(ref);
      if (snap.exists()) {
        setContent(snap.data());
      }
      setLoading(false);
    }
    fetchPage();
  }, [db, pageId]);

  const handleSave = async () => {
    setSaving(true);
    try {
      const ref = doc(db, 'pages', pageId as string);
      await setDoc(ref, content, { merge: true });
      toast({ title: "Page Updated", description: "Changes have been synchronized with the live platform." });
    } catch (e) {
      toast({ variant: "destructive", title: "Error", description: "Could not save content to Firestore." });
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <div className="h-screen flex items-center justify-center"><Loader2 className="h-10 w-10 animate-spin text-primary" /></div>;

  return (
    <SidebarProvider>
      <AdminSidebar />
      <SidebarInset>
        <header className="flex h-16 shrink-0 items-center gap-4 border-b bg-background px-6 sticky top-0 z-50">
          <Button variant="ghost" size="icon" onClick={() => router.back()}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div className="flex-1 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <h1 className="font-headline font-bold text-xl uppercase tracking-tighter">Edit: {pageId}</h1>
              <Badge variant="outline" className="text-[10px]">CMS-DRIVEN</Badge>
            </div>
            <Button size="sm" onClick={handleSave} disabled={saving}>
              {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
              Save Orchestration
            </Button>
          </div>
        </header>

        <main className="p-8 max-w-4xl mx-auto">
          <Tabs defaultValue="hero" className="space-y-8">
            <TabsList className="bg-muted/50 p-1">
              <TabsTrigger value="hero">Hero Segment</TabsTrigger>
              <TabsTrigger value="sections">Dynamic Sections</TabsTrigger>
              <TabsTrigger value="seo">SEO & Metadata</TabsTrigger>
            </TabsList>

            <TabsContent value="hero" className="space-y-6">
              <Card className="border-primary/10 shadow-lg">
                <CardHeader>
                  <CardTitle className="font-headline">Hero Content Orchestration</CardTitle>
                  <CardDescription>Configure the primary impact section of your page.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label>Hero Title</Label>
                      <Input 
                        value={content.hero?.title} 
                        onChange={(e) => setContent({...content, hero: {...content.hero, title: e.target.value}})}
                        placeholder="Master the Future of EdTech"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>CTA Text</Label>
                      <Input 
                        value={content.hero?.ctaText} 
                        onChange={(e) => setContent({...content, hero: {...content.hero, ctaText: e.target.value}})}
                        placeholder="Explore Courses"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Subtitle / Description</Label>
                    <Textarea 
                      value={content.hero?.subtitle} 
                      onChange={(e) => setContent({...content, hero: {...content.hero, subtitle: e.target.value}})}
                      placeholder="Combine enterprise-grade architecture with AI..."
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Visual Asset (URL)</Label>
                    <div className="flex gap-2">
                      <Input 
                        value={content.hero?.imageUrl} 
                        onChange={(e) => setContent({...content, hero: {...content.hero, imageUrl: e.target.value}})}
                        placeholder="https://cloudinary.com/..."
                      />
                      <Button variant="outline" size="icon"><ImageIcon className="h-4 w-4" /></Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-primary/10 bg-primary/5">
                <CardContent className="pt-6">
                  <div className="flex items-center gap-4">
                    <div className="h-12 w-12 rounded-full bg-primary flex items-center justify-center text-white">
                      <Sparkles className="h-6 w-6" />
                    </div>
                    <div>
                      <p className="font-bold">AI Suggestion</p>
                      <p className="text-sm text-muted-foreground">Vasant suggests using high-impact action verbs in your hero title for 24% better conversion.</p>
                    </div>
                    <Button size="sm" variant="secondary" className="ml-auto">Optimize</Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="sections" className="space-y-6">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-headline font-bold">Page Structure</h3>
                <Button size="sm"><Plus className="mr-2 h-4 w-4" /> Add Section</Button>
              </div>
              
              <div className="space-y-4">
                {(content.sections || []).map((section: any, i: number) => (
                  <Card key={i} className="group border-dashed hover:border-primary transition-colors">
                    <CardHeader className="flex flex-row items-center justify-between p-4">
                      <div className="flex items-center gap-3">
                        <Badge variant="outline" className="capitalize">{section.type}</Badge>
                        <CardTitle className="text-sm font-medium">{section.title}</CardTitle>
                      </div>
                      <Button variant="ghost" size="sm" className="h-8 text-destructive">Remove</Button>
                    </CardHeader>
                  </Card>
                ))}
                {!content.sections?.length && (
                  <div className="text-center py-12 border-2 border-dashed rounded-2xl text-muted-foreground">
                    No dynamic sections configured. Add your first content block!
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </main>
      </SidebarInset>
    </SidebarProvider>
  );
}
