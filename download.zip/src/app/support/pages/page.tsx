'use client';

import { SidebarProvider, SidebarInset, SidebarTrigger } from "@/components/ui/sidebar";
import { AdminSidebar } from "@/components/admin/sidebar";
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Globe, ArrowRight, Eye, Edit2, Layout, Trash2 } from "lucide-react";
import Link from "next/link";
import { Badge } from "@/components/ui/badge";

const PAGES = [
  { id: 'home', title: 'Homepage', description: 'Hero, Features, Testimonials, CTA', status: 'Published' },
  { id: 'about', title: 'About Us', description: 'Mission, Vision, Story, Team', status: 'Published' },
  { id: 'courses', title: 'Course Library', description: 'Categories, Filters, Grid', status: 'Published' },
  { id: 'community', title: 'Community Hub', description: 'Channels, Highlights, Reviews', status: 'Draft' },
  { id: 'blog', title: 'Blog Engine', description: 'Search, Categories, Featured', status: 'Published' },
];

export default function PagesManagement() {
  return (
    <SidebarProvider>
      <AdminSidebar />
      <SidebarInset className="bg-muted/10">
        <header className="flex h-16 shrink-0 items-center gap-4 border-b bg-background px-6">
          <SidebarTrigger />
          <h1 className="font-headline font-bold text-xl">Content Orchestration</h1>
        </header>

        <main className="p-8 max-w-6xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-3xl font-headline font-bold">Manage Pages</h2>
              <p className="text-muted-foreground">Modify static and dynamic page components across the ecosystem.</p>
            </div>
            <Button className="bg-primary shadow-lg shadow-primary/20">
              <Layout className="mr-2 h-4 w-4" /> Custom Page
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {PAGES.map((page) => (
              <Card key={page.id} className="group hover:border-primary/50 transition-all shadow-sm">
                <CardHeader className="flex flex-row items-start justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <div className="h-8 w-8 rounded-lg bg-primary/5 flex items-center justify-center text-primary">
                        <Globe className="h-4 w-4" />
                      </div>
                      <CardTitle className="font-headline text-xl">{page.title}</CardTitle>
                    </div>
                    <CardDescription>{page.description}</CardDescription>
                  </div>
                  <Badge variant={page.status === 'Published' ? 'default' : 'outline'} className={page.status === 'Published' ? 'bg-green-100 text-green-800' : ''}>
                    {page.status}
                  </Badge>
                </CardHeader>
                <CardContent className="pt-2">
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" className="flex-1" asChild>
                      <Link href={`/${page.id}`} target="_blank">
                        <Eye className="mr-2 h-3 w-3" /> View Live
                      </Link>
                    </Button>
                    <Button variant="outline" size="sm" className="flex-1" asChild>
                      <Link href={`/support/pages/${page.id}`}>
                        <Edit2 className="mr-2 h-3 w-3" /> Edit CMS
                      </Link>
                    </Button>
                    <Button variant="ghost" size="icon" className="text-destructive hover:bg-destructive/10">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </main>
      </SidebarInset>
    </SidebarProvider>
  );
}
