
'use client';

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import SupportDashboard from "../page";
import { motion, AnimatePresence } from "framer-motion";
import { ShieldAlert, Clock, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function TimeGatedAdmin() {
  const { token } = useParams();
  const router = useRouter();
  const [isAuthorized, setIsAuthorized] = useState<boolean | null>(null);

  useEffect(() => {
    const checkAccess = () => {
      const now = new Date();
      const hh = String(now.getHours()).padStart(2, '0');
      const mm = String(now.getMinutes()).padStart(2, '0');
      const expectedToken = `${hh}${mm}`;
      
      if (token === expectedToken) {
        setIsAuthorized(true);
      } else {
        setIsAuthorized(false);
      }
    };

    checkAccess();
    // Re-check every minute to stay synced with HHmm
    const interval = setInterval(checkAccess, 60000);
    return () => clearInterval(interval);
  }, [token]);

  if (isAuthorized === null) return null;

  if (!isAuthorized) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-6 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="space-y-8 max-w-md"
        >
          <div className="h-24 w-24 bg-destructive/10 rounded-full flex items-center justify-center mx-auto text-destructive">
            <ShieldAlert className="h-12 w-12" />
          </div>
          <div className="space-y-4">
            <h1 className="text-4xl font-headline font-bold tracking-tighter text-destructive">ACCESS REJECTED</h1>
            <p className="text-muted-foreground">
              Your orchestration token is invalid or has expired. Access to the Admin Console v2.0 requires a valid 24hr time-synced key.
            </p>
            <div className="flex items-center justify-center gap-2 bg-muted p-4 rounded-xl font-mono text-sm">
              <Clock className="h-4 w-4" />
              Expected Format: /support/HHmm
            </div>
          </div>
          <Button onClick={() => router.push('/')} variant="outline" className="h-12 w-full rounded-xl font-bold">
            <ArrowLeft className="mr-2 h-4 w-4" /> Return to Safety
          </Button>
        </motion.div>
      </div>
    );
  }

  return <SupportDashboard />;
}
