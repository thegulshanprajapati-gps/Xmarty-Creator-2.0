'use client';

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Calendar, User, Clock, ArrowRight } from "lucide-react";
import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

const BLOGS = [
  {
    id: '1',
    title: 'The Future of Web Architecture in 2024',
    excerpt: 'Exploring how server-side rendering and AI-driven design are reshaping the digital landscape...',
    author: 'Admin Sarah',
    date: 'Oct 24, 2024',
    readTime: '8 min',
    category: 'Technology',
    image: 'https://picsum.photos/seed/blog1/800/500'
  },
  {
    id: '2',
    title: 'Mastering the XmartyCreator Workflow',
    excerpt: 'A comprehensive guide to using our dynamic CMS and enterprise modules for your next big project...',
    author: 'Marcus Aurelius',
    date: 'Oct 20, 2024',
    readTime: '12 min',
    category: 'Guide',
    image: 'https://picsum.photos/seed/blog2/800/500'
  },
  {
    id: '3',
    title: 'Why AI-Powered Learning is the New Gold Standard',
    excerpt: 'How tools like Vasant AI are helping students bridge the gap between theory and real-world execution...',
    author: 'Vasant AI Team',
    date: 'Oct 15, 2024',
    readTime: '6 min',
    category: 'AI',
    image: 'https://picsum.photos/seed/blog3/800/500'
  }
];

export default function BlogPage() {
  return (
    <div className="min-h-screen bg-background">
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="space-y-20">
          {/* Header */}
          <div className="text-center max-w-3xl mx-auto space-y-6">
            <Badge className="bg-primary/10 text-primary border-primary/20 px-4 py-1 rounded-full font-bold">INSIGHTS</Badge>
            <h1 className="text-6xl lg:text-8xl font-headline font-bold tracking-tight">XmartyCreator <span className="text-primary">Journal</span></h1>
            <p className="text-xl text-muted-foreground leading-relaxed">
              Exploring the intersection of engineering excellence, design integrity, and educational innovation.
            </p>
            <div className="max-w-md mx-auto pt-8">
              <div className="relative group">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground group-focus-within:text-primary transition-colors" />
                <Input placeholder="Search insights..." className="pl-12 h-14 rounded-2xl border-2 focus-visible:ring-primary shadow-lg" />
              </div>
            </div>
          </div>

          {/* Featured Blog */}
          <div className="relative rounded-[3rem] overflow-hidden bg-muted aspect-[21/9] group shadow-2xl">
            <Image src={BLOGS[0].image} alt="Featured" fill className="object-cover transition-transform duration-1000 group-hover:scale-105" data-ai-hint="featured blog" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex flex-col justify-end p-12 text-white">
              <div className="space-y-4 max-w-2xl">
                <Badge className="bg-accent text-accent-foreground border-none font-bold">FEATURED ARTICLE</Badge>
                <h2 className="text-4xl md:text-6xl font-headline font-bold leading-tight">{BLOGS[0].title}</h2>
                <p className="text-lg opacity-80 line-clamp-2">{BLOGS[0].excerpt}</p>
                <Button size="lg" className="bg-white text-black hover:bg-white/90 font-bold rounded-xl h-14 px-8 mt-4">
                  Read Article <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </div>
            </div>
          </div>

          {/* Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
            {BLOGS.map((blog, idx) => (
              <motion.div
                key={blog.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                viewport={{ once: true }}
              >
                <Card className="border-none bg-transparent group cursor-pointer shadow-none">
                  <div className="relative aspect-[16/10] rounded-[2rem] overflow-hidden mb-6 shadow-xl border border-primary/5">
                    <Image src={blog.image} alt={blog.title} fill className="object-cover transition-transform duration-700 group-hover:scale-110" data-ai-hint="blog post" />
                    <Badge className="absolute top-4 right-4 bg-white/90 text-black border-none font-bold backdrop-blur-sm">{blog.category}</Badge>
                  </div>
                  <div className="space-y-4">
                    <div className="flex items-center gap-4 text-xs font-bold text-muted-foreground uppercase tracking-widest">
                      <div className="flex items-center gap-1"><Calendar className="h-3 w-3" /> {blog.date}</div>
                      <div className="flex items-center gap-1"><Clock className="h-3 w-3" /> {blog.readTime}</div>
                    </div>
                    <CardTitle className="text-2xl font-headline font-bold group-hover:text-primary transition-colors leading-tight">{blog.title}</CardTitle>
                    <p className="text-muted-foreground line-clamp-2 leading-relaxed">{blog.excerpt}</p>
                    <div className="flex items-center justify-between pt-4 border-t border-primary/5">
                      <div className="flex items-center gap-2">
                        <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xs uppercase">SA</div>
                        <span className="text-sm font-bold">{blog.author}</span>
                      </div>
                      <Link href={`/blog/${blog.id}`} className="text-primary font-bold text-sm flex items-center group-hover:translate-x-1 transition-transform">
                        Read More <ArrowRight className="ml-1 h-4 w-4" />
                      </Link>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
