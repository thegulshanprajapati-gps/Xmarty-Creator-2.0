'use client';

import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent, CardFooter, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { GraduationCap, ShieldCheck, ArrowRight, Loader2, Lock, Info, User } from "lucide-react";
import Link from "next/link";
import { motion } from "framer-motion";
import { useRouter } from "next/navigation";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function StudentLogin() {
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const router = useRouter();
  const { toast } = useToast();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    // Simulate authentication
    setTimeout(() => {
      setLoading(false);
      toast({
        title: "Welcome to XmartyCreator",
        description: "You have successfully logged into your learning portal.",
      });
      router.push('/');
    }, 1200);
  };

  return (
    <div className="min-h-screen bg-muted/30 flex items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-full -z-10">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 blur-[120px] rounded-full" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/10 blur-[120px] rounded-full" />
      </div>

      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4 }}
        className="w-full max-w-md"
      >
        <div className="text-center mb-10">
          <Link href="/" className="inline-flex items-center gap-3 mb-6 group">
            <div className="bg-primary p-3 rounded-2xl group-hover:rotate-12 transition-all shadow-xl shadow-primary/30">
              <GraduationCap className="h-8 w-8 text-primary-foreground" />
            </div>
            <span className="font-headline text-3xl font-bold tracking-tighter text-primary">
              XmartyCreator
            </span>
          </Link>
          <h1 className="text-sm font-bold text-muted-foreground uppercase tracking-[0.3em]">
            Student Portal Entry
          </h1>
        </div>

        <Card className="border-primary/10 shadow-2xl overflow-hidden bg-background/80 backdrop-blur-xl">
          <div className="h-1.5 w-full bg-primary" />
          <CardHeader className="space-y-2 p-8 text-center">
            <CardTitle className="text-3xl font-headline font-bold">Welcome Back</CardTitle>
            <CardDescription className="text-base">
              Enter your credentials to access your learning dashboard.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6 p-8 pt-0">
            <form onSubmit={handleLogin} className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-sm font-bold">Student Email</Label>
                <Input 
                  id="email" 
                  type="email" 
                  placeholder="student@xmartycreator.com" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="h-12 border-2 focus:ring-primary rounded-xl"
                  required 
                />
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password" title="Access Key" className="text-sm font-bold">Password</Label>
                  <Link href="#" className="text-xs text-primary font-bold hover:underline">Forgot Password?</Link>
                </div>
                <Input 
                  id="password" 
                  type="password" 
                  placeholder="••••••••" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="h-12 border-2 focus:ring-primary rounded-xl"
                  required 
                />
              </div>
              <Button type="submit" className="w-full bg-primary h-14 text-lg font-bold shadow-xl shadow-primary/20 rounded-xl" disabled={loading}>
                {loading ? (
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                ) : (
                  <>
                    Sign In
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </>
                )}
              </Button>
            </form>
            
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-background px-2 text-muted-foreground font-bold">New to XmartyCreator?</span>
              </div>
            </div>
            
            <Button variant="outline" className="w-full h-14 rounded-xl border-2 font-bold" asChild>
              <Link href="#">Create Student Account</Link>
            </Button>
          </CardContent>
          <CardFooter className="bg-muted/30 p-6 flex flex-col items-center gap-2">
            <p className="text-[10px] text-muted-foreground flex items-center gap-2 font-bold uppercase tracking-widest">
              <ShieldCheck className="h-3 w-3" /> Encrypted Session Active
            </p>
          </CardFooter>
        </Card>

        <div className="mt-10 text-center">
          <Link href="/" className="text-sm font-bold text-muted-foreground hover:text-primary transition-colors inline-flex items-center gap-2">
            Return to Public Platform
          </Link>
        </div>
      </motion.div>
    </div>
  );
}
