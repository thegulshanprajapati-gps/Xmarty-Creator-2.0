import { Metadata } from 'next';
import './globals.css';
import { FirebaseClientProvider } from "@/firebase";
import { CMSProvider } from "@/components/cms-provider";
import { ClientLayoutShell } from "@/components/client-layout-shell";

export const metadata: Metadata = {
  title: 'XmartyCreator',
  description: 'Enterprise EdTech Orchestration Platform',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet" />
      </head>
      <body className="font-body antialiased bg-background text-foreground min-h-screen flex flex-col overflow-x-hidden w-full">
        <FirebaseClientProvider>
          <CMSProvider>
            <ClientLayoutShell>
              {children}
            </ClientLayoutShell>
          </CMSProvider>
        </FirebaseClientProvider>
      </body>
    </html>
  );
}