'use client';

import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MessageSquare, Users, Star, ArrowRight, Zap, Share2, Globe, Heart } from "lucide-react";
import Image from "next/image";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

export default function CommunityPage() {
  const highlights = [
    { title: "Weekly Study Circles", count: "12 Groups", icon: Users },
    { title: "Active Discussions", count: "450+ Daily", icon: MessageSquare },
    { title: "Live Code Reviews", count: "Every Friday", icon: Zap },
  ];

  return (
    <div className="min-h-screen">
      <main>
        {/* Hero */}
        <section className="py-32 relative overflow-hidden bg-primary text-primary-foreground">
          <div className="absolute top-0 right-0 w-1/3 h-full opacity-10 pointer-events-none">
            <Users className="w-full h-full text-white" />
          </div>
          <div className="max-w-7xl mx-auto px-4 relative z-10 space-y-8 text-center lg:text-left">
            <Badge className="bg-white/20 text-white border-none px-4 py-2 rounded-full font-bold">GLOBAL ECOSYSTEM</Badge>
            <h1 className="text-6xl lg:text-8xl font-headline font-bold tracking-tight">
              Learn <span className="text-accent underline decoration-wavy">Together</span>.
            </h1>
            <p className="text-2xl opacity-80 max-w-3xl leading-relaxed">
              XmartyCreator is more than just videos. Join 45,000+ passionate creators, developers, and designers building the future together.
            </p>
            <div className="flex flex-wrap gap-4 justify-center lg:justify-start pt-8">
              <Button size="lg" className="bg-white text-primary hover:bg-white/90 h-16 px-10 font-bold text-xl rounded-2xl shadow-2xl">Join Discord Hub</Button>
              <Button variant="outline" size="lg" className="border-white/20 hover:bg-white/10 h-16 px-10 font-bold text-xl rounded-2xl">Browse Circles</Button>
            </div>
          </div>
        </section>

        {/* Highlight Stats */}
        <section className="py-12 bg-muted/20 border-b">
          <div className="max-w-7xl mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {highlights.map((h, i) => (
                <div key={i} className="flex items-center gap-6 p-8 bg-background rounded-[2rem] shadow-sm border border-primary/5">
                  <div className="h-16 w-16 bg-primary/10 rounded-2xl flex items-center justify-center text-primary">
                    <h.icon className="h-8 w-8" />
                  </div>
                  <div>
                    <h4 className="font-bold text-xl">{h.title}</h4>
                    <p className="text-muted-foreground text-sm font-bold uppercase tracking-widest">{h.count}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Hub Selection */}
        <section className="py-32">
          <div className="max-w-7xl mx-auto px-4 space-y-20">
            <div className="text-center space-y-4">
              <Badge variant="outline" className="text-primary border-primary/20">THE CHANNELS</Badge>
              <h2 className="text-5xl font-headline font-bold">Choose Your Hub</h2>
              <p className="text-xl text-muted-foreground">Pick the platform that fits your learning style at XmartyCreator.</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
              <HubCard 
                title="The Discord Matrix" 
                desc="Our primary engineering hub for technical discussions, real-time help, and live streaming events." 
                platform="Discord"
                color="bg-indigo-500"
                image="https://picsum.photos/seed/discord/600/400"
              />
              <HubCard 
                title="WhatsApp Circles" 
                desc="Fast, focused groups for course announcements, quick updates, and local community meetups." 
                platform="WhatsApp"
                color="bg-green-500"
                image="https://picsum.photos/seed/whatsapp/600/400"
              />
              <HubCard 
                title="Telegram Broadcasts" 
                desc="Instant access to resource drops, career alerts, and platform news straight to your phone." 
                platform="Telegram"
                color="bg-blue-500"
                image="https://picsum.photos/seed/telegram/600/400"
              />
            </div>
          </div>
        </section>

        {/* Community Benefits */}
        <section className="py-32 bg-muted/10">
          <div className="max-w-7xl mx-auto px-4 flex flex-col lg:flex-row gap-20 items-center">
            <div className="flex-1 w-full relative aspect-video rounded-[3rem] overflow-hidden shadow-2xl border-[12px] border-white dark:border-white/5">
              <Image src="https://picsum.photos/seed/community/800/600" alt="Meetup" fill className="object-cover" data-ai-hint="tech meetup" />
            </div>
            <div className="flex-1 space-y-12">
              <div className="space-y-4">
                <Badge className="bg-accent text-accent-foreground font-bold rounded-full">WHY JOIN?</Badge>
                <h2 className="text-5xl font-headline font-bold">More than just a community.</h2>
                <p className="text-xl text-muted-foreground leading-relaxed">
                  XmartyCreator is a launchpad where creators support each other through every step of their journey.
                </p>
              </div>
              <ul className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {[
                  "Peer-to-peer code reviews.",
                  "Exclusive job postings.",
                  "Direct educator access.",
                  "Collaborative projects.",
                  "24/7 technical support.",
                  "Portfolio development."
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-4 group">
                    <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary shrink-0 group-hover:bg-primary group-hover:text-white transition-colors">
                      <Heart className="h-5 w-5 fill-current" />
                    </div>
                    <span className="text-lg font-bold text-muted-foreground">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}

function HubCard({ title, desc, platform, color, image }: any) {
  return (
    <Card className="overflow-hidden group border-primary/5 hover:border-primary transition-all duration-500 rounded-[2.5rem] shadow-lg">
      <div className="relative aspect-video overflow-hidden">
        <Image src={image} alt={platform} fill className="object-cover group-hover:scale-110 transition-transform duration-700" data-ai-hint={platform} />
        <Badge className={cn("absolute top-6 right-6 text-white border-none px-4 py-2 font-bold shadow-lg", color)}>{platform}</Badge>
      </div>
      <CardHeader className="p-8">
        <CardTitle className="text-3xl font-headline leading-tight">{title}</CardTitle>
      </CardHeader>
      <CardContent className="p-8 pt-0 space-y-8">
        <p className="text-muted-foreground text-lg leading-relaxed">{desc}</p>
        <Button className="w-full h-14 font-bold text-lg rounded-xl group-hover:shadow-2xl transition-all">
          Join {platform} <ArrowRight className="ml-2 h-5 w-5" />
        </Button>
      </CardContent>
    </Card>
  );
}
