'use client';

import { Navbar } from "@/components/navbar";
import { Footer } from "@/components/footer";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { CheckCircle2, Award, Zap, Users, Rocket, Heart } from "lucide-react";
import Image from "next/image";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

export default function AboutPage() {
  const values = [
    { title: "Innovation", icon: Rocket, desc: "We push the boundaries of EdTech through AI and modern design." },
    { title: "Quality", icon: Award, desc: "Only the highest standard of industry-relevant curriculum." },
    { title: "Community", icon: Users, desc: "A collaborative ecosystem where creators grow together." },
    { title: "Passion", icon: Heart, desc: "We are educators first, driven by the success of our students." },
  ];

  return (
    <div className="min-h-screen">
      <main>
        {/* Hero */}
        <section className="py-24 bg-muted/20">
          <div className="max-w-7xl mx-auto px-4 text-center space-y-8">
            <Badge variant="outline" className="px-4 py-1 text-primary border-primary/20">WHO WE ARE</Badge>
            <h1 className="text-6xl lg:text-8xl font-headline font-bold tracking-tight">
              We are <span className="text-primary">XmartyCreator</span>.
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
              XmartyCreator is more than an EdTech platform; it's a launchpad for the next generation of digital architects and creators. We bridge the gap between academic theory and enterprise reality.
            </p>
          </div>
        </section>

        {/* Story */}
        <section className="py-32">
          <div className="max-w-7xl mx-auto px-4 flex flex-col lg:flex-row items-center gap-20">
            <div className="flex-1 space-y-8">
              <h2 className="text-5xl font-headline font-bold leading-tight">Our Story</h2>
              <div className="space-y-6 text-lg text-muted-foreground leading-relaxed">
                <p>
                  XmartyCreator was born out of a simple observation: the tech industry was moving faster than traditional education could keep up. Students were graduating with skills that were already obsolete.
                </p>
                <p>
                  In 2021, we set out to build a platform that treated learning like professional development. We didn't just want to teach code; we wanted to teach architectural thinking, scalability, and design excellence.
                </p>
                <p>
                  Today, XmartyCreator is home to over 45,000 students globally, powered by the Vasant AI Assistant and mentored by some of the brightest minds in the industry.
                </p>
              </div>
            </div>
            <div className="flex-1 w-full relative aspect-square rounded-[3rem] overflow-hidden shadow-2xl">
              <Image src="https://picsum.photos/seed/about/800/800" alt="Team Workshop" fill className="object-cover" data-ai-hint="team work" />
            </div>
          </div>
        </section>

        {/* Values */}
        <section className="py-32 bg-primary text-primary-foreground">
          <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-8">
            {values.map((v, i) => (
              <div key={i} className="p-8 rounded-3xl border border-white/10 hover:bg-white/5 transition-all space-y-6 text-center group">
                <div className="h-16 w-16 bg-white/10 rounded-2xl flex items-center justify-center text-accent mx-auto group-hover:scale-110 transition-transform">
                  <v.icon className="h-8 w-8" />
                </div>
                <h4 className="text-2xl font-bold">{v.title}</h4>
                <p className="opacity-80">{v.desc}</p>
              </div>
            ))}
          </div>
        </section>

        {/* FAQ */}
        <section className="py-32 bg-muted/20">
          <div className="max-w-4xl mx-auto px-4 space-y-16">
            <div className="text-center space-y-4">
              <h2 className="text-5xl font-headline font-bold">Frequently Asked Questions</h2>
              <p className="text-xl text-muted-foreground">Everything you need to know about the XmartyCreator ecosystem.</p>
            </div>
            <Accordion type="single" collapsible className="w-full space-y-4">
              {[
                { q: "Is XmartyCreator suitable for beginners?", a: "Absolutely. Our curriculum starts from foundations and scales to enterprise levels, ensuring anyone with passion can learn." },
                { q: "What makes Vasant AI different?", a: "Vasant is trained specifically on our curriculum to provide context-aware, 24/7 technical guidance that feels like a real tutor." },
                { q: "Do I get a certificate?", a: "Yes, every completed course includes an industry-verified digital certificate that you can share on LinkedIn." },
                { q: "Can I access courses offline?", a: "Our platform is optimized for web access, but all resource materials and code templates are downloadable for offline use." }
              ].map((faq, i) => (
                <AccordionItem key={i} value={`item-${i}`} className="border-none bg-background rounded-2xl px-6">
                  <AccordionTrigger className="text-lg font-bold hover:no-underline">{faq.q}</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground text-base leading-relaxed">
                    {faq.a}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </section>
      </main>
    </div>
  );
}
