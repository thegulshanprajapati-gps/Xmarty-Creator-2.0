'use client';

import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { GraduationCap, Rocket, ShieldCheck, Zap, ArrowRight, Star, Users, Award, BookOpen, Globe } from "lucide-react";
import Image from "next/image";
import Link from "next/link";
import { useDoc } from "@/firebase";
import { useCMS } from "@/components/cms-provider";
import { doc, getFirestore } from "firebase/firestore";
import { motion } from "framer-motion";
import { Footer } from "@/components/footer";

export default function Home() {
  const { settings } = useCMS();
  const db = getFirestore();
  const homeRef = doc(db, 'pages', 'home');
  const { data: homeContent } = useDoc(homeRef);

  const heroData = homeContent?.hero || {
    title: "Master the Future of EdTech Excellence.",
    subtitle: "XmartyCreator combines enterprise-grade architecture with personalized AI mentoring to deliver a learning experience that scales with your ambition.",
    ctaText: "Explore Courses",
    ctaHref: "/courses"
  };

  const stats = [
    { label: "Active Students", value: "45.2k+", icon: Users },
    { label: "Expert Courses", value: "120+", icon: BookOpen },
    { label: "Global Reach", value: "85+", icon: Globe },
    { label: "Success Rate", value: "98%", icon: Award },
  ];

  return (
    <div className="bg-background w-full max-w-full overflow-x-hidden">
      {/* Hero Section */}
      <section className="flex items-center relative overflow-hidden px-4 md:px-8 w-full pt-16">
        <div className="absolute top-0 right-0 -z-10 w-2/3 h-full opacity-10 blur-[120px] bg-primary animate-pulse"></div>
        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row items-center gap-12 w-full h-full justify-center">
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="flex-1 space-y-6 text-center lg:text-left"
          >
            <Badge className="bg-primary/10 text-primary px-4 py-1.5 rounded-full border-primary/20 font-bold">
              {settings?.announcement || "✨ Discover XmartyCreator Path"}
            </Badge>
            <h1 className="text-5xl md:text-7xl lg:text-[5.5rem] font-headline font-bold leading-[0.95] tracking-tighter text-foreground">
              {heroData.title}
            </h1>
            <p className="text-lg text-muted-foreground max-w-xl leading-relaxed font-medium">
              {heroData.subtitle}
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button asChild size="lg" className="h-16 px-10 text-xl font-bold bg-primary shadow-2xl shadow-primary/30 hover:-translate-y-1 transition-all group rounded-2xl">
                <Link href={heroData.ctaHref}>
                  {heroData.ctaText}
                  <ArrowRight className="ml-2 h-6 w-6 group-hover:translate-x-1 transition-transform" />
                </Link>
              </Button>
              <Button variant="outline" size="lg" className="h-16 px-10 text-xl font-bold border-2 rounded-2xl hover:bg-muted/50">
                Join Community
              </Button>
            </div>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1 }}
            className="flex-1 hidden lg:block w-full max-w-xl"
          >
            <div className="relative aspect-[4/5] rounded-[3rem] overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.2)] border-[12px] border-background dark:border-muted/20">
              <Image
                src={heroData.imageUrl || "https://picsum.photos/seed/1/800/1000"}
                alt="XmartyCreator Platform"
                fill
                className="object-cover"
                priority
              />
            </div>
          </motion.div>
        </div>
      </section>

      {/* Stats & Mission */}
      <section className="flex flex-col justify-center px-4 bg-muted/20 w-full">
        <div className="max-w-7xl mx-auto w-full space-y-20">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((s, i) => (
              <div key={i} className="text-center group">
                <h4 className="text-4xl md:text-6xl font-bold font-headline text-primary group-hover:scale-110 transition-transform duration-500">{s.value}</h4>
                <p className="text-xs text-muted-foreground uppercase tracking-[0.3em] font-bold mt-2">{s.label}</p>
              </div>
            ))}
          </div>
          <div className="text-center max-w-3xl mx-auto space-y-8">
            <Badge variant="outline" className="text-primary border-primary/20 font-bold px-6 py-1 uppercase tracking-widest">OUR MISSION</Badge>
            <h2 className="text-4xl md:text-6xl font-headline font-bold tracking-tight text-foreground">We Provide Excellence!!</h2>
            <p className="text-2xl text-muted-foreground italic font-medium leading-relaxed">
              "Empowering the next generation of digital architects through industrial orchestration."
            </p>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="flex flex-col justify-center px-4 bg-background w-full">
        <div className="max-w-7xl mx-auto w-full">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 h-full py-12">
            <FeatureCard icon={GraduationCap} title="Premium Courses" description="Expert-led curriculum focused on enterprise standards." />
            <FeatureCard icon={Users} title="Career Mentorship" description="One-on-one professional guidance with industry veterans." />
            <FeatureCard icon={Rocket} title="Internship Support" description="Connect with top tech firms for real-world projects." />
            <FeatureCard icon={ShieldCheck} title="Certificates" description="Earn industry-recognized professional credentials." />
            <FeatureCard icon={Zap} title="Live Sessions" description="Interactive workshops for real-time problem solving." />
            <FeatureCard icon={Award} title="Placement Prep" description="Comprehensive portfolio and technical assessment training." />
            <FeatureCard icon={Globe} title="Community Hub" description="Network with thousands of like-minded creators." />
            <FeatureCard icon={BookOpen} title="Resource Library" description="Unlimited access to enterprise code templates." />
          </div>
        </div>
      </section>

      {/* Footer snapped at the end */}
      <section className="flex flex-col justify-end w-full overflow-y-auto scrollbar-hide">
        <Footer />
      </section>
    </div>
  );
}

function FeatureCard({ icon: Icon, title, description }: any) {
  return (
    <Card className="group hover:bg-primary transition-all duration-500 hover:shadow-2xl border-primary/5 rounded-[2rem] overflow-hidden flex flex-col justify-center min-h-[140px]">
      <CardHeader className="p-6 pb-2">
        <div className="h-10 w-10 bg-primary/10 rounded-xl flex items-center justify-center text-primary group-hover:bg-white/20 group-hover:text-white transition-all duration-500 group-hover:rotate-6">
          <Icon className="h-5 w-5" />
        </div>
        <CardTitle className="text-lg font-headline font-bold group-hover:text-white transition-colors mt-3">{title}</CardTitle>
      </CardHeader>
      <CardContent className="px-6 pb-6">
        <p className="text-xs text-muted-foreground group-hover:text-white/80 transition-colors leading-relaxed font-medium">
          {description}
        </p>
      </CardContent>
    </Card>
  );
}