'use client';

import React, { createContext, useContext, useEffect, useState } from 'react';
import { useDoc } from '@/firebase'; // Assuming this is the correct path for useDoc hook
import { doc, getFirestore } from 'firebase/firestore';

interface CMSContextType {
  settings: any;
  loading: boolean;
}

const CMSContext = createContext<CMSContextType>({ settings: null, loading: true });

export const CMSProvider = ({ children }: { children: React.ReactNode }) => {
  const db = getFirestore();
  // Assuming 'config' is the collection and 'settings' is the document ID
  const settingsRef = doc(db, 'config', 'settings'); 
  const { data: settings, loading } = useDoc(settingsRef);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    if (settings && mounted) {
      // Apply Theme Mode (Dark/Light)
      if (settings.themeMode === 'dark') {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }

      // Inject Dynamic Orchestration Styles with High Specificity
      let styleTag = document.getElementById('cms-dynamic-orchestration');
      if (!styleTag) {
        styleTag = document.createElement('style');
        styleTag.id = 'cms-dynamic-orchestration';
        document.head.appendChild(styleTag);
      }

      // Use provided colors or fallbacks
      const primary = settings.primaryColor || "231 48% 48%"; // Default to blue if not set
      const accent = settings.accentColor || primary;

      const css = `
        :root { 
          --primary: ${primary} !important; 
          --ring: ${primary} !important;
          --accent: ${accent} !important;
        }
        .dark { 
          --primary: ${primary} !important; 
          --ring: ${primary} !important;
          --accent: ${accent} !important;
        }
        
        /* Aggressive Color Propagation */
        .bg-primary { background-color: hsl(${primary}) !important; }
        .text-primary { color: hsl(${primary}) !important; }
        .border-primary { border-color: hsl(${primary}) !important; }
        .decoration-primary { text-decoration-color: hsl(${primary}) !important; }
        .fill-primary { fill: hsl(${primary}) !important; }
        .bg-accent { background-color: hsl(${accent}) !important; }
        .text-accent { color: hsl(${accent}) !important; }
      `;
      styleTag.innerHTML = css;
    }
  }, [settings, mounted]);

  // Corrected the syntax for passing the value prop
  return (
    <CMSContext.Provider value={{ settings, loading }}>
      {children}
    </CMSContext.Provider>
  );
};

export const useCMS = () => useContext(CMSContext);
